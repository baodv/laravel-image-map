<?php
Route::get('demo-image-map',function(){
    return 'contact';
});